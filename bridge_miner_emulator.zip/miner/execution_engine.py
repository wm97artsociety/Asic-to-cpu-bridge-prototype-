# Runs mining loop, combines CPU+network power
