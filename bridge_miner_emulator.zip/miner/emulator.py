# ASIC-to-CPU emulation logic + virtual CPU power
