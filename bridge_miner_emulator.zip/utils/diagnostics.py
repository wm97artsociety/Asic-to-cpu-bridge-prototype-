# Network speed measurement & system checks
