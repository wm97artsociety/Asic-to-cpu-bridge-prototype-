# Simple logging utility
