# Entry point for your bridge miner terminal
