# Terminal UI to show mining stats and control
