# Connects to mining pool, fetches jobs
