# Submits shares to mining pool
