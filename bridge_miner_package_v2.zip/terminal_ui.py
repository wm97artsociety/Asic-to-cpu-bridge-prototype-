# UI to show mining stats
