# Connects to mining pool
