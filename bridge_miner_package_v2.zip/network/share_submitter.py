# Submits shares
