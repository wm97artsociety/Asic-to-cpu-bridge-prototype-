# ASIC-to-CPU emulation logic
