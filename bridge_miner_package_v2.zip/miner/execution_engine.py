# Executes mining loop
